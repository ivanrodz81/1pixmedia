import sys
import os
import json
import urllib
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import random
import base64
import urllib2
import server

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
addonset	= ['4d4441364d5545364e7a67364f444d364d6a45364e54513d'.decode('hex').decode('base64'),'4d4441364d5545364e7a67364e5445364d7a4d364d7a513d'.decode('hex').decode('base64'),'4d4441364d5545364e7a67364d6a4d364d7a51364e44553d'.decode('hex').decode('base64'),'4d4441364d5545364e7a67364d5449364d7a51364f54413d'.decode('hex').decode('base64')]
eternal		= (random.choice(addonset))
current     = os.getcwd()

def portalConfig(number):

	portal = {};
	
	portal['parental'] = addon.getSetting("parental");
	portal['password'] = addon.getSetting("password");
	
	portal['name'] = addon.getSetting("portal_name_" + number);
	portal['url'] = addon.getSetting("portal_url_" + number);
	portal['mac'] = configMac(number);
	portal['serial'] = configSerialNumber(number);
		
	return portal;


def configMac(number):
	global go;
	import urllib2

	custom_mac = ('Y3VzdG9tX21hY18x'.decode('base64'));
	portal_mac = ('cG9ydGFsX21hY18x'.decode('base64'));
	
	if custom_mac != 'true':
		portal_mac = (eternal);
		
	elif not (custom_mac == 'true' and re.match("WzAtOWEtZl17Mn0oWy06XSlbMC05YS1mXXsyfShcXDFbMC05YS1mXXsyfSl7NH0k".decode('base64'), portal_mac.lower()) != None):
		xbmcgui.Dialog().notification(addonname, 'Custom Mac ' + number + ' is Invalid.', xbmcgui.NOTIFICATION_ERROR );
		portal_mac = '';
		go=False;
		
	return portal_mac;
	
	
def configSerialNumber(number):
	global go;
	
	send_serial = addon.getSetting('c2VuZF9zZXJpYWxf'.decode('base64') + number);
	custom_serial = addon.getSetting('Y3VzdG9tX3NlcmlhbF8='.decode('base64') + number);
	serial_number = addon.getSetting('c2VyaWFsX251bWJlcl8='.decode('base64') + number);
	device_id = addon.getSetting('ZGV2aWNlX2lkXw=='.decode('base64') + number);
	device_id2 = addon.getSetting('ZGV2aWNlX2lkMl8='.decode('base64') + number);
	signature = addon.getSetting('c2lnbmF0dXJlXw=='.decode('base64') + number);

	
	if send_serial != 'true':
		return None;
	
	elif send_serial == 'true' and custom_serial == 'false':
		return {'custom' : False};
		
	elif send_serial == 'true' and custom_serial == 'true':
	
		if serial_number == '' or device_id == '' or device_id2 == '' or signature == '':
			xbmcgui.Dialog().notification(addonname, 'Serial information is invalid.', xbmcgui.NOTIFICATION_ERROR );
			go=False;
			return None;
	
		return {'custom' : True, 'sn' : serial_number, 'device_id' : device_id, 'device_id2' : device_id2, 'signature' : signature};
		
	return None;